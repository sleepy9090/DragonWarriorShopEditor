﻿DragonWarriorShopEditor 1.0.1.28437
Coded by: Shawn M. Crawford [sleepy9090]
February 8, 2018

-Requires .NET Framework 3.5

DragonWarriorShopEditor
Shop Editor for Dragon Warrior USA NES
Change prices for items in shops.
Change items available in shops.

-Tested with headered Dragon Warrior (U) (PRG0) [!].nes ROM.
-Tested with headered Dragon Warrior (U) (PRG1) [!].nes ROM.

Feel free to send bugs to sleepy3d@email.com or file them on github: https://github.com/sleepy9090

Version: 1.0.1.28437 February 8, 2018
-add better error handling and textbox validation

Version: 1.0.0.30614 February 4, 2018
-first version

